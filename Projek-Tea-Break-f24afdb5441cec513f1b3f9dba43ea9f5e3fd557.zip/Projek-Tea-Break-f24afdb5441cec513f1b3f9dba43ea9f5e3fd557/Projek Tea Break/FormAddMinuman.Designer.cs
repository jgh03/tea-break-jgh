﻿
namespace Projek_Tea_Break
{
    partial class FormAddMinuman
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.buttonOk = new System.Windows.Forms.Button();
            this.labelTopping = new System.Windows.Forms.Label();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.panelTopping = new System.Windows.Forms.Panel();
            this.textBoxBub = new System.Windows.Forms.TextBox();
            this.textBoxPud = new System.Windows.Forms.TextBox();
            this.textBoxBro = new System.Windows.Forms.TextBox();
            this.textBoxGra = new System.Windows.Forms.TextBox();
            this.textBoxChe = new System.Windows.Forms.TextBox();
            this.textBoxRai = new System.Windows.Forms.TextBox();
            this.textBoxPL = new System.Windows.Forms.TextBox();
            this.textBoxPM = new System.Windows.Forms.TextBox();
            this.butttonPlusGra = new System.Windows.Forms.Button();
            this.buttonPlusBub = new System.Windows.Forms.Button();
            this.buttonPlusBro = new System.Windows.Forms.Button();
            this.buttonPlusPud = new System.Windows.Forms.Button();
            this.buttonPlusChe = new System.Windows.Forms.Button();
            this.buttonPlusRai = new System.Windows.Forms.Button();
            this.buttonMinBub = new System.Windows.Forms.Button();
            this.buttonMinGras = new System.Windows.Forms.Button();
            this.buttonMinBro = new System.Windows.Forms.Button();
            this.buttonMinPud = new System.Windows.Forms.Button();
            this.buttonMinChe = new System.Windows.Forms.Button();
            this.buttonMinRai = new System.Windows.Forms.Button();
            this.buttonMinPL = new System.Windows.Forms.Button();
            this.buttonMinPM = new System.Windows.Forms.Button();
            this.textBoxPS = new System.Windows.Forms.TextBox();
            this.buttonPlusPL = new System.Windows.Forms.Button();
            this.buttonPlusPM = new System.Windows.Forms.Button();
            this.buttonPlusPS = new System.Windows.Forms.Button();
            this.buttonMinPS = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.imageListMinuman = new System.Windows.Forms.ImageList(this.components);
            this.labelMinuman = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.buttonGambar = new System.Windows.Forms.Button();
            this.buttonPlusQty = new System.Windows.Forms.Button();
            this.buttonMinQty = new System.Windows.Forms.Button();
            this.textBoxQty = new System.Windows.Forms.TextBox();
            this.rBSugarLess = new System.Windows.Forms.RadioButton();
            this.rBSugarNormal = new System.Windows.Forms.RadioButton();
            this.rBSugarMore = new System.Windows.Forms.RadioButton();
            this.rBIceLess = new System.Windows.Forms.RadioButton();
            this.rBIceNormal = new System.Windows.Forms.RadioButton();
            this.rBIceMore = new System.Windows.Forms.RadioButton();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panelTopping.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonOk
            // 
            this.buttonOk.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonOk.Location = new System.Drawing.Point(413, 376);
            this.buttonOk.Name = "buttonOk";
            this.buttonOk.Size = new System.Drawing.Size(197, 98);
            this.buttonOk.TabIndex = 1;
            this.buttonOk.Text = "OK";
            this.buttonOk.UseVisualStyleBackColor = true;
            this.buttonOk.Click += new System.EventHandler(this.buttonOk_Click);
            // 
            // labelTopping
            // 
            this.labelTopping.AutoSize = true;
            this.labelTopping.Font = new System.Drawing.Font("Microsoft YaHei", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTopping.Location = new System.Drawing.Point(12, 173);
            this.labelTopping.Name = "labelTopping";
            this.labelTopping.Size = new System.Drawing.Size(93, 26);
            this.labelTopping.TabIndex = 5;
            this.labelTopping.Text = "Topping";
            // 
            // buttonCancel
            // 
            this.buttonCancel.BackColor = System.Drawing.Color.Red;
            this.buttonCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCancel.Location = new System.Drawing.Point(413, 493);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(197, 98);
            this.buttonCancel.TabIndex = 6;
            this.buttonCancel.Text = "Cancel";
            this.buttonCancel.UseVisualStyleBackColor = false;
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
            // 
            // panelTopping
            // 
            this.panelTopping.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panelTopping.Controls.Add(this.textBoxBub);
            this.panelTopping.Controls.Add(this.textBoxPud);
            this.panelTopping.Controls.Add(this.textBoxBro);
            this.panelTopping.Controls.Add(this.textBoxGra);
            this.panelTopping.Controls.Add(this.textBoxChe);
            this.panelTopping.Controls.Add(this.textBoxRai);
            this.panelTopping.Controls.Add(this.textBoxPL);
            this.panelTopping.Controls.Add(this.textBoxPM);
            this.panelTopping.Controls.Add(this.butttonPlusGra);
            this.panelTopping.Controls.Add(this.buttonPlusBub);
            this.panelTopping.Controls.Add(this.buttonPlusBro);
            this.panelTopping.Controls.Add(this.buttonPlusPud);
            this.panelTopping.Controls.Add(this.buttonPlusChe);
            this.panelTopping.Controls.Add(this.buttonPlusRai);
            this.panelTopping.Controls.Add(this.buttonMinBub);
            this.panelTopping.Controls.Add(this.buttonMinGras);
            this.panelTopping.Controls.Add(this.buttonMinBro);
            this.panelTopping.Controls.Add(this.buttonMinPud);
            this.panelTopping.Controls.Add(this.buttonMinChe);
            this.panelTopping.Controls.Add(this.buttonMinRai);
            this.panelTopping.Controls.Add(this.buttonMinPL);
            this.panelTopping.Controls.Add(this.buttonMinPM);
            this.panelTopping.Controls.Add(this.textBoxPS);
            this.panelTopping.Controls.Add(this.buttonPlusPL);
            this.panelTopping.Controls.Add(this.buttonPlusPM);
            this.panelTopping.Controls.Add(this.buttonPlusPS);
            this.panelTopping.Controls.Add(this.buttonMinPS);
            this.panelTopping.Controls.Add(this.label11);
            this.panelTopping.Controls.Add(this.label10);
            this.panelTopping.Controls.Add(this.label9);
            this.panelTopping.Controls.Add(this.label8);
            this.panelTopping.Controls.Add(this.label7);
            this.panelTopping.Controls.Add(this.label6);
            this.panelTopping.Controls.Add(this.label5);
            this.panelTopping.Controls.Add(this.label4);
            this.panelTopping.Controls.Add(this.label3);
            this.panelTopping.Controls.Add(this.label1);
            this.panelTopping.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panelTopping.Location = new System.Drawing.Point(13, 212);
            this.panelTopping.Name = "panelTopping";
            this.panelTopping.Size = new System.Drawing.Size(380, 379);
            this.panelTopping.TabIndex = 7;
            // 
            // textBoxBub
            // 
            this.textBoxBub.Location = new System.Drawing.Point(294, 17);
            this.textBoxBub.Name = "textBoxBub";
            this.textBoxBub.Size = new System.Drawing.Size(25, 22);
            this.textBoxBub.TabIndex = 34;
            this.textBoxBub.Text = "0";
            this.textBoxBub.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxPud
            // 
            this.textBoxPud.Location = new System.Drawing.Point(294, 137);
            this.textBoxPud.Name = "textBoxPud";
            this.textBoxPud.Size = new System.Drawing.Size(25, 22);
            this.textBoxPud.TabIndex = 33;
            this.textBoxPud.Text = "0";
            this.textBoxPud.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxBro
            // 
            this.textBoxBro.Location = new System.Drawing.Point(294, 97);
            this.textBoxBro.Name = "textBoxBro";
            this.textBoxBro.Size = new System.Drawing.Size(25, 22);
            this.textBoxBro.TabIndex = 32;
            this.textBoxBro.Text = "0";
            this.textBoxBro.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxGra
            // 
            this.textBoxGra.Location = new System.Drawing.Point(294, 57);
            this.textBoxGra.Name = "textBoxGra";
            this.textBoxGra.Size = new System.Drawing.Size(25, 22);
            this.textBoxGra.TabIndex = 31;
            this.textBoxGra.Text = "0";
            this.textBoxGra.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxChe
            // 
            this.textBoxChe.Location = new System.Drawing.Point(294, 177);
            this.textBoxChe.Name = "textBoxChe";
            this.textBoxChe.Size = new System.Drawing.Size(25, 22);
            this.textBoxChe.TabIndex = 17;
            this.textBoxChe.Text = "0";
            this.textBoxChe.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxRai
            // 
            this.textBoxRai.Location = new System.Drawing.Point(294, 217);
            this.textBoxRai.Name = "textBoxRai";
            this.textBoxRai.Size = new System.Drawing.Size(25, 22);
            this.textBoxRai.TabIndex = 18;
            this.textBoxRai.Text = "0";
            this.textBoxRai.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxPL
            // 
            this.textBoxPL.Location = new System.Drawing.Point(294, 257);
            this.textBoxPL.Name = "textBoxPL";
            this.textBoxPL.Size = new System.Drawing.Size(25, 22);
            this.textBoxPL.TabIndex = 19;
            this.textBoxPL.Text = "0";
            this.textBoxPL.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxPM
            // 
            this.textBoxPM.Location = new System.Drawing.Point(294, 297);
            this.textBoxPM.Name = "textBoxPM";
            this.textBoxPM.Size = new System.Drawing.Size(25, 22);
            this.textBoxPM.TabIndex = 20;
            this.textBoxPM.Text = "0";
            this.textBoxPM.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // butttonPlusGra
            // 
            this.butttonPlusGra.Location = new System.Drawing.Point(325, 56);
            this.butttonPlusGra.Name = "butttonPlusGra";
            this.butttonPlusGra.Size = new System.Drawing.Size(25, 25);
            this.butttonPlusGra.TabIndex = 30;
            this.butttonPlusGra.Text = "+";
            this.butttonPlusGra.UseCompatibleTextRendering = true;
            this.butttonPlusGra.UseVisualStyleBackColor = true;
            // 
            // buttonPlusBub
            // 
            this.buttonPlusBub.Location = new System.Drawing.Point(325, 16);
            this.buttonPlusBub.Name = "buttonPlusBub";
            this.buttonPlusBub.Size = new System.Drawing.Size(25, 25);
            this.buttonPlusBub.TabIndex = 29;
            this.buttonPlusBub.Text = "+";
            this.buttonPlusBub.UseCompatibleTextRendering = true;
            this.buttonPlusBub.UseVisualStyleBackColor = true;
            // 
            // buttonPlusBro
            // 
            this.buttonPlusBro.Location = new System.Drawing.Point(325, 96);
            this.buttonPlusBro.Name = "buttonPlusBro";
            this.buttonPlusBro.Size = new System.Drawing.Size(25, 25);
            this.buttonPlusBro.TabIndex = 17;
            this.buttonPlusBro.Text = "+";
            this.buttonPlusBro.UseCompatibleTextRendering = true;
            this.buttonPlusBro.UseVisualStyleBackColor = true;
            // 
            // buttonPlusPud
            // 
            this.buttonPlusPud.Location = new System.Drawing.Point(325, 136);
            this.buttonPlusPud.Name = "buttonPlusPud";
            this.buttonPlusPud.Size = new System.Drawing.Size(25, 25);
            this.buttonPlusPud.TabIndex = 18;
            this.buttonPlusPud.Text = "+";
            this.buttonPlusPud.UseCompatibleTextRendering = true;
            this.buttonPlusPud.UseVisualStyleBackColor = true;
            // 
            // buttonPlusChe
            // 
            this.buttonPlusChe.Location = new System.Drawing.Point(325, 176);
            this.buttonPlusChe.Name = "buttonPlusChe";
            this.buttonPlusChe.Size = new System.Drawing.Size(25, 25);
            this.buttonPlusChe.TabIndex = 19;
            this.buttonPlusChe.Text = "+";
            this.buttonPlusChe.UseCompatibleTextRendering = true;
            this.buttonPlusChe.UseVisualStyleBackColor = true;
            // 
            // buttonPlusRai
            // 
            this.buttonPlusRai.Location = new System.Drawing.Point(325, 216);
            this.buttonPlusRai.Name = "buttonPlusRai";
            this.buttonPlusRai.Size = new System.Drawing.Size(25, 25);
            this.buttonPlusRai.TabIndex = 20;
            this.buttonPlusRai.Text = "+";
            this.buttonPlusRai.UseCompatibleTextRendering = true;
            this.buttonPlusRai.UseVisualStyleBackColor = true;
            // 
            // buttonMinBub
            // 
            this.buttonMinBub.Location = new System.Drawing.Point(263, 16);
            this.buttonMinBub.Name = "buttonMinBub";
            this.buttonMinBub.Size = new System.Drawing.Size(25, 25);
            this.buttonMinBub.TabIndex = 18;
            this.buttonMinBub.Text = "-";
            this.buttonMinBub.UseCompatibleTextRendering = true;
            this.buttonMinBub.UseVisualStyleBackColor = true;
            // 
            // buttonMinGras
            // 
            this.buttonMinGras.Location = new System.Drawing.Point(263, 56);
            this.buttonMinGras.Name = "buttonMinGras";
            this.buttonMinGras.Size = new System.Drawing.Size(25, 25);
            this.buttonMinGras.TabIndex = 19;
            this.buttonMinGras.Text = "-";
            this.buttonMinGras.UseCompatibleTextRendering = true;
            this.buttonMinGras.UseVisualStyleBackColor = true;
            // 
            // buttonMinBro
            // 
            this.buttonMinBro.Location = new System.Drawing.Point(263, 96);
            this.buttonMinBro.Name = "buttonMinBro";
            this.buttonMinBro.Size = new System.Drawing.Size(25, 25);
            this.buttonMinBro.TabIndex = 20;
            this.buttonMinBro.Text = "-";
            this.buttonMinBro.UseCompatibleTextRendering = true;
            this.buttonMinBro.UseVisualStyleBackColor = true;
            // 
            // buttonMinPud
            // 
            this.buttonMinPud.Location = new System.Drawing.Point(263, 136);
            this.buttonMinPud.Name = "buttonMinPud";
            this.buttonMinPud.Size = new System.Drawing.Size(25, 25);
            this.buttonMinPud.TabIndex = 21;
            this.buttonMinPud.Text = "-";
            this.buttonMinPud.UseCompatibleTextRendering = true;
            this.buttonMinPud.UseVisualStyleBackColor = true;
            // 
            // buttonMinChe
            // 
            this.buttonMinChe.Location = new System.Drawing.Point(263, 176);
            this.buttonMinChe.Name = "buttonMinChe";
            this.buttonMinChe.Size = new System.Drawing.Size(25, 25);
            this.buttonMinChe.TabIndex = 22;
            this.buttonMinChe.Text = "-";
            this.buttonMinChe.UseCompatibleTextRendering = true;
            this.buttonMinChe.UseVisualStyleBackColor = true;
            // 
            // buttonMinRai
            // 
            this.buttonMinRai.Location = new System.Drawing.Point(263, 216);
            this.buttonMinRai.Name = "buttonMinRai";
            this.buttonMinRai.Size = new System.Drawing.Size(25, 25);
            this.buttonMinRai.TabIndex = 23;
            this.buttonMinRai.Text = "-";
            this.buttonMinRai.UseCompatibleTextRendering = true;
            this.buttonMinRai.UseVisualStyleBackColor = true;
            // 
            // buttonMinPL
            // 
            this.buttonMinPL.Location = new System.Drawing.Point(263, 256);
            this.buttonMinPL.Name = "buttonMinPL";
            this.buttonMinPL.Size = new System.Drawing.Size(25, 25);
            this.buttonMinPL.TabIndex = 24;
            this.buttonMinPL.Text = "-";
            this.buttonMinPL.UseCompatibleTextRendering = true;
            this.buttonMinPL.UseVisualStyleBackColor = true;
            // 
            // buttonMinPM
            // 
            this.buttonMinPM.Location = new System.Drawing.Point(263, 296);
            this.buttonMinPM.Name = "buttonMinPM";
            this.buttonMinPM.Size = new System.Drawing.Size(25, 25);
            this.buttonMinPM.TabIndex = 25;
            this.buttonMinPM.Text = "-";
            this.buttonMinPM.UseCompatibleTextRendering = true;
            this.buttonMinPM.UseVisualStyleBackColor = true;
            // 
            // textBoxPS
            // 
            this.textBoxPS.Location = new System.Drawing.Point(294, 337);
            this.textBoxPS.Name = "textBoxPS";
            this.textBoxPS.Size = new System.Drawing.Size(25, 22);
            this.textBoxPS.TabIndex = 26;
            this.textBoxPS.Text = "0";
            this.textBoxPS.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // buttonPlusPL
            // 
            this.buttonPlusPL.Location = new System.Drawing.Point(325, 256);
            this.buttonPlusPL.Name = "buttonPlusPL";
            this.buttonPlusPL.Size = new System.Drawing.Size(25, 25);
            this.buttonPlusPL.TabIndex = 26;
            this.buttonPlusPL.Text = "+";
            this.buttonPlusPL.UseCompatibleTextRendering = true;
            this.buttonPlusPL.UseVisualStyleBackColor = true;
            // 
            // buttonPlusPM
            // 
            this.buttonPlusPM.Location = new System.Drawing.Point(325, 296);
            this.buttonPlusPM.Name = "buttonPlusPM";
            this.buttonPlusPM.Size = new System.Drawing.Size(25, 25);
            this.buttonPlusPM.TabIndex = 27;
            this.buttonPlusPM.Text = "+";
            this.buttonPlusPM.UseCompatibleTextRendering = true;
            this.buttonPlusPM.UseVisualStyleBackColor = true;
            // 
            // buttonPlusPS
            // 
            this.buttonPlusPS.Location = new System.Drawing.Point(325, 336);
            this.buttonPlusPS.Name = "buttonPlusPS";
            this.buttonPlusPS.Size = new System.Drawing.Size(25, 25);
            this.buttonPlusPS.TabIndex = 28;
            this.buttonPlusPS.Text = "+";
            this.buttonPlusPS.UseCompatibleTextRendering = true;
            this.buttonPlusPS.UseVisualStyleBackColor = true;
            // 
            // buttonMinPS
            // 
            this.buttonMinPS.Location = new System.Drawing.Point(263, 336);
            this.buttonMinPS.Name = "buttonMinPS";
            this.buttonMinPS.Size = new System.Drawing.Size(25, 25);
            this.buttonMinPS.TabIndex = 26;
            this.buttonMinPS.Text = "-";
            this.buttonMinPS.UseCompatibleTextRendering = true;
            this.buttonMinPS.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(23, 340);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(132, 17);
            this.label11.TabIndex = 9;
            this.label11.Text = "Popping Strawberry";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(23, 300);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(107, 17);
            this.label10.TabIndex = 8;
            this.label10.Text = "Popping Mango";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(23, 260);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(110, 17);
            this.label9.TabIndex = 7;
            this.label9.Text = "Popping Lychee";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(23, 220);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(94, 17);
            this.label8.TabIndex = 6;
            this.label8.Text = "Rainbow Jelly";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(23, 180);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(101, 17);
            this.label7.TabIndex = 5;
            this.label7.Text = "Cheese Cream";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(23, 140);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(60, 17);
            this.label6.TabIndex = 4;
            this.label6.Text = "Pudding";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(23, 140);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 17);
            this.label5.TabIndex = 3;
            this.label5.Text = "label5";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(23, 100);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 17);
            this.label4.TabIndex = 2;
            this.label4.Text = "Brown Sugar";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(23, 60);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 17);
            this.label3.TabIndex = 1;
            this.label3.Text = "Grass Jelly";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Bubble";
            // 
            // imageListMinuman
            // 
            this.imageListMinuman.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageListMinuman.ImageSize = new System.Drawing.Size(90, 90);
            this.imageListMinuman.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // labelMinuman
            // 
            this.labelMinuman.AutoSize = true;
            this.labelMinuman.Font = new System.Drawing.Font("Myanmar Text", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMinuman.Location = new System.Drawing.Point(444, 212);
            this.labelMinuman.Name = "labelMinuman";
            this.labelMinuman.Size = new System.Drawing.Size(137, 30);
            this.labelMinuman.TabIndex = 11;
            this.labelMinuman.Text = "Nama Minuman";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(436, 253);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 17);
            this.label2.TabIndex = 12;
            this.label2.Text = "Jumlah :";
            // 
            // buttonGambar
            // 
            this.buttonGambar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonGambar.Enabled = false;
            this.buttonGambar.Location = new System.Drawing.Point(410, 12);
            this.buttonGambar.Name = "buttonGambar";
            this.buttonGambar.Size = new System.Drawing.Size(200, 200);
            this.buttonGambar.TabIndex = 13;
            this.buttonGambar.Text = " ";
            this.buttonGambar.UseVisualStyleBackColor = true;
            // 
            // buttonPlusQty
            // 
            this.buttonPlusQty.Location = new System.Drawing.Point(560, 252);
            this.buttonPlusQty.Name = "buttonPlusQty";
            this.buttonPlusQty.Size = new System.Drawing.Size(25, 25);
            this.buttonPlusQty.TabIndex = 14;
            this.buttonPlusQty.Text = "+";
            this.buttonPlusQty.UseCompatibleTextRendering = true;
            this.buttonPlusQty.UseVisualStyleBackColor = true;
            // 
            // buttonMinQty
            // 
            this.buttonMinQty.Location = new System.Drawing.Point(498, 252);
            this.buttonMinQty.Name = "buttonMinQty";
            this.buttonMinQty.Size = new System.Drawing.Size(25, 25);
            this.buttonMinQty.TabIndex = 15;
            this.buttonMinQty.Text = "-";
            this.buttonMinQty.UseCompatibleTextRendering = true;
            this.buttonMinQty.UseVisualStyleBackColor = true;
            // 
            // textBoxQty
            // 
            this.textBoxQty.Location = new System.Drawing.Point(529, 252);
            this.textBoxQty.Name = "textBoxQty";
            this.textBoxQty.Size = new System.Drawing.Size(25, 22);
            this.textBoxQty.TabIndex = 16;
            this.textBoxQty.Text = "1";
            this.textBoxQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // rBSugarLess
            // 
            this.rBSugarLess.AutoSize = true;
            this.rBSugarLess.Location = new System.Drawing.Point(14, 9);
            this.rBSugarLess.Name = "rBSugarLess";
            this.rBSugarLess.Size = new System.Drawing.Size(59, 21);
            this.rBSugarLess.TabIndex = 17;
            this.rBSugarLess.Tag = "L";
            this.rBSugarLess.Text = "Less";
            this.rBSugarLess.UseVisualStyleBackColor = true;
            // 
            // rBSugarNormal
            // 
            this.rBSugarNormal.AutoSize = true;
            this.rBSugarNormal.Checked = true;
            this.rBSugarNormal.Location = new System.Drawing.Point(14, 49);
            this.rBSugarNormal.Name = "rBSugarNormal";
            this.rBSugarNormal.Size = new System.Drawing.Size(74, 21);
            this.rBSugarNormal.TabIndex = 18;
            this.rBSugarNormal.TabStop = true;
            this.rBSugarNormal.Tag = "N";
            this.rBSugarNormal.Text = "Normal";
            this.rBSugarNormal.UseVisualStyleBackColor = true;
            // 
            // rBSugarMore
            // 
            this.rBSugarMore.AutoSize = true;
            this.rBSugarMore.Location = new System.Drawing.Point(14, 89);
            this.rBSugarMore.Name = "rBSugarMore";
            this.rBSugarMore.Size = new System.Drawing.Size(61, 21);
            this.rBSugarMore.TabIndex = 19;
            this.rBSugarMore.Tag = "M";
            this.rBSugarMore.Text = "More";
            this.rBSugarMore.UseVisualStyleBackColor = true;
            // 
            // rBIceLess
            // 
            this.rBIceLess.AutoSize = true;
            this.rBIceLess.Location = new System.Drawing.Point(10, 9);
            this.rBIceLess.Name = "rBIceLess";
            this.rBIceLess.Size = new System.Drawing.Size(59, 21);
            this.rBIceLess.TabIndex = 20;
            this.rBIceLess.Tag = "L";
            this.rBIceLess.Text = "Less";
            this.rBIceLess.UseVisualStyleBackColor = true;
            // 
            // rBIceNormal
            // 
            this.rBIceNormal.AutoSize = true;
            this.rBIceNormal.Checked = true;
            this.rBIceNormal.Location = new System.Drawing.Point(10, 49);
            this.rBIceNormal.Name = "rBIceNormal";
            this.rBIceNormal.Size = new System.Drawing.Size(74, 21);
            this.rBIceNormal.TabIndex = 21;
            this.rBIceNormal.TabStop = true;
            this.rBIceNormal.Tag = "N";
            this.rBIceNormal.Text = "Normal";
            this.rBIceNormal.UseVisualStyleBackColor = true;
            // 
            // rBIceMore
            // 
            this.rBIceMore.AutoSize = true;
            this.rBIceMore.Location = new System.Drawing.Point(10, 89);
            this.rBIceMore.Name = "rBIceMore";
            this.rBIceMore.Size = new System.Drawing.Size(61, 21);
            this.rBIceMore.TabIndex = 22;
            this.rBIceMore.Tag = "M";
            this.rBIceMore.Text = "More";
            this.rBIceMore.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft YaHei", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(12, 12);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(122, 26);
            this.label12.TabIndex = 23;
            this.label12.Text = "Sugar Level";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft YaHei", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(229, 12);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(94, 26);
            this.label13.TabIndex = 24;
            this.label13.Text = "Ice Level";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.rBSugarLess);
            this.panel1.Controls.Add(this.rBSugarNormal);
            this.panel1.Controls.Add(this.rBSugarMore);
            this.panel1.Location = new System.Drawing.Point(22, 41);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(108, 129);
            this.panel1.TabIndex = 25;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.rBIceNormal);
            this.panel2.Controls.Add(this.rBIceMore);
            this.panel2.Controls.Add(this.rBIceLess);
            this.panel2.Location = new System.Drawing.Point(234, 41);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(108, 129);
            this.panel2.TabIndex = 26;
            // 
            // FormAddMinuman
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(632, 603);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.textBoxQty);
            this.Controls.Add(this.buttonMinQty);
            this.Controls.Add(this.buttonPlusQty);
            this.Controls.Add(this.buttonGambar);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.labelMinuman);
            this.Controls.Add(this.panelTopping);
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.labelTopping);
            this.Controls.Add(this.buttonOk);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Name = "FormAddMinuman";
            this.Text = "FormAddMinuman";
            this.Load += new System.EventHandler(this.FormAddMinuman_Load);
            this.panelTopping.ResumeLayout(false);
            this.panelTopping.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button buttonOk;
        private System.Windows.Forms.Label labelTopping;
        private System.Windows.Forms.Button buttonCancel;
        private System.Windows.Forms.Panel panelTopping;
        private System.Windows.Forms.ImageList imageListMinuman;
        private System.Windows.Forms.Label labelMinuman;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button buttonGambar;
        private System.Windows.Forms.Button buttonPlusQty;
        private System.Windows.Forms.Button buttonMinQty;
        private System.Windows.Forms.TextBox textBoxQty;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxBub;
        private System.Windows.Forms.TextBox textBoxPud;
        private System.Windows.Forms.TextBox textBoxBro;
        private System.Windows.Forms.TextBox textBoxGra;
        private System.Windows.Forms.TextBox textBoxChe;
        private System.Windows.Forms.TextBox textBoxRai;
        private System.Windows.Forms.TextBox textBoxPL;
        private System.Windows.Forms.TextBox textBoxPM;
        private System.Windows.Forms.Button butttonPlusGra;
        private System.Windows.Forms.Button buttonPlusBub;
        private System.Windows.Forms.Button buttonPlusBro;
        private System.Windows.Forms.Button buttonPlusPud;
        private System.Windows.Forms.Button buttonPlusChe;
        private System.Windows.Forms.Button buttonPlusRai;
        private System.Windows.Forms.Button buttonMinBub;
        private System.Windows.Forms.Button buttonMinGras;
        private System.Windows.Forms.Button buttonMinBro;
        private System.Windows.Forms.Button buttonMinPud;
        private System.Windows.Forms.Button buttonMinChe;
        private System.Windows.Forms.Button buttonMinRai;
        private System.Windows.Forms.Button buttonMinPL;
        private System.Windows.Forms.Button buttonMinPM;
        private System.Windows.Forms.TextBox textBoxPS;
        private System.Windows.Forms.Button buttonPlusPL;
        private System.Windows.Forms.Button buttonPlusPM;
        private System.Windows.Forms.Button buttonPlusPS;
        private System.Windows.Forms.Button buttonMinPS;
        private System.Windows.Forms.RadioButton rBSugarLess;
        private System.Windows.Forms.RadioButton rBSugarNormal;
        private System.Windows.Forms.RadioButton rBSugarMore;
        private System.Windows.Forms.RadioButton rBIceLess;
        private System.Windows.Forms.RadioButton rBIceNormal;
        private System.Windows.Forms.RadioButton rBIceMore;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
    }
}